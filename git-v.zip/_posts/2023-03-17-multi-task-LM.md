---
layout: post
title:  What can Language Models learn? A case of domain knowledge transfer
header: CS224N Final Project 
categories: [ NLP, Multi-Task ]
image: assets/images/nlp.png
featured: true
hidden: true
comments: false
img: ../assets/images/stanford.jpg
---